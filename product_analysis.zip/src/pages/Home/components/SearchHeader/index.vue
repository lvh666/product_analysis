<template>
  <div class="logo">logo</div>
</template>

<script>
export default {
  name: "SearchHeader",
};
</script>
<style scoped>
.logo {
  margin-top: 15%;
  color: red;
  text-align: center;
  font-size: 60px;
}
</style>
