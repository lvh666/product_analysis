<template>
  <div>
    <SearchHeader />
    <SearchForm />
  </div>
</template>

<script>
import SearchHeader from "./components/SearchHeader";
import SearchForm from "./components/SearchForm";

export default {
  name: "Home",
  components: {
    SearchForm,
    SearchHeader,
  },
};
</script>
