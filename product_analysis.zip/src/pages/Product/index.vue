<template>
  <div>
    <SearchForm />
    <ProductItem />
  </div>
</template>

<script>
import ProductItem from "./components/ProductItem";
import SearchForm from "../SearchResult/components/SearchForm";

export default {
  name: "Product",
  components: {
    SearchForm,
    ProductItem,
  },
};
</script>
