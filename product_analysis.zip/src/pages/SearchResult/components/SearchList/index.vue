<template>
  <div class="list">
    <div class="v-card" v-for="item in data" :key="item.id">
      <el-card class="box-card">
        <div class="product-img" @click="toItem(item.id)">
          <img :src="item.src" alt="图片" />
        </div>
        <div class="product-title" @click="toItem(item.id)">
          {{ item.title }}
        </div>
        <div class="product-price">
          <em>￥</em>
          <div class="product-listpricespan">{{ item.price }}</div>
        </div>
      </el-card>
    </div>
  </div>
</template>

<script>
export default {
  name: "SearchList",
  data() {
    return {
      data: [
        {
          id: "s-1",
          src: "",
          title:
            "Apple iPhone 12 (A2404) 128GB 绿色 支持移动联通电信5G 双卡双待手机",
          price: 6799,
        },
        {
          id: "s-2",
          src: "",
          title:
            "Apple iPhone 12 (A2404) 128GB 黑色 支持移动联通电信5G 双卡双待手机",
          price: 6799,
        },
      ],
    };
  },
  methods: {
    toItem(id) {
      this.$router.push({
        path: `/product`,
        query: {
          id: id,
        },
      });
    },
  },
};
</script>
<style scoped>
.list {
  position: absolute;
  top: 15%;
  left: 20%;
  width: 80%;
}
.v-card {
  margin-top: 10px;
}
.clearfix:before,
.clearfix:after {
  display: table;
  content: "";
}
.clearfix:after {
  clear: both;
}

.box-card {
  width: 75%;
}

.product-img {
  float: left;
  width: 160px;
  height: 160px;
  cursor: pointer;
}

.product-title {
  float: left;
  width: 400px;
  font-size: 14px;
  cursor: pointer;
}

.product-price {
  float: left;
  margin-left: 10px;
  width: 160px;
  color: #cc0000;
  font-weight: bold;
}
.product-price em {
  float: left;
  font-size: 12px;
  font-style: normal;
}
.product-price .product-listpricespan {
  float: left;
  font-size: 20px;
  line-height: 10px;
}
</style>
