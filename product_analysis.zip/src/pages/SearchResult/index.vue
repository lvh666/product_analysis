<template>
  <div class="searchbg">
    <SearchForm />
    <SearchList />
  </div>
</template>

<script>
import SearchList from "./components/SearchList";
import SearchForm from "./components/SearchForm";

export default {
  name: "SearchResult",
  components: {
    SearchForm,
    SearchList,
  },
};
</script>

<style>
.searchbg {
  overflow: hidden;
}
</style>
