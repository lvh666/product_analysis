import Vue from "vue";
import Router from "vue-router";
import Home from "@/pages/Home";
import Search from "@/pages/SearchResult";
import Product from "@/pages/Product";

Vue.use(Router);

export default new Router({
  routes: [
    {
      path: "/",
      name: "Home",
      component: Home,
    },
    {
      path: "/search",
      name: "Search",
      component: Search,
    },
    {
      path: "/product",
      name: "Product",
      component: Product,
    },
  ],
});
